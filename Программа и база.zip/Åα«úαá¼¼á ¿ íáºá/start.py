# -*- coding cp-1252 -*-
import time
#import sys
from bit import Key
import os
from bit.format import bytes_to_wif
from multiprocessing import Lock, Process, cpu_count
from os import system

def get_babulesy(numpotok, k_count, profit_file, base_file, lock):

        pid = os.getpid()
        lock.acquire()
        print("попытка №", pid, numpotok, ' чтение базы данных...', flush=True)
        start = time.time()
        t = frozenset([line.rstrip('\n') for line in open(base_file, 'r', encoding="cp1252")])
        print('time read:',time.time() - start, flush=True)
        del(start)
        lock.release()
        y=0
        while True:
                #key generation unit
                y+=1

                mass={}
                for _ in range(k_count):
                        k = Key() #kompressed key
                        mass[k.address]=k.to_wif() #address made from compressed key
                        mass[k.segwit_address]=k.to_wif() #segwit address made from compressed key
                        wif = bytes_to_wif(k.to_bytes(), compressed=False) #uncompressed key
                        k1 = Key(wif) #address made from uncompressed key
                        mass[k1.address]=wif
                        dol = '0'
                        balance = '0'
                        system("title " + "   Майнинг v2.0 - @chance_wallet_bot  //  Всего проверено: " + str(y)  + "  //  [Найдено " + balance + " BTC] " + "≈ [" + dol + "$]")

                #verification of addresses
                print("генерация mnemonic phrase №", y, " | ", k, ' |  верификация...', pid, flush=True)

                vall_set=set(mass.keys())
                c=vall_set.intersection(t)
                if c:
                        print("генерация mnemonic phrase №", y,'найден кошелёк с балансом!', flush=True)
                        system("title " + "   Майнинг v2.0 - @chance_wallet_bot  //  Проверено генераций: " + str(y)  + "  //  [Найдено " + balance + " BTC] " + "- [" + balance + "$]")
                        with open(profit_file,'a') as out:
                                for gg in c:
                                        out.write('{},{}\n'.format(gg,mass[gg]))

                                out.close()



if __name__ == '__main__':
        key_count = 1
        pat=os.path.dirname(__file__)
        baseName=pat+'\\base.txt'
        profit=pat+'\\out.txt'

        lock=Lock()

        procs=[]
        for u in range(1):
                proc = Process(target=get_babulesy, args=(u, key_count, profit, baseName, lock))
                procs.append(proc)
                proc.start()

        for proc in procs:
                proc.join()